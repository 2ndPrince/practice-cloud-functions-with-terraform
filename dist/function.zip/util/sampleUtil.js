"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateSomething = void 0;
const calculateSomething = (a, b) => {
    return a + b;
};
exports.calculateSomething = calculateSomething;
